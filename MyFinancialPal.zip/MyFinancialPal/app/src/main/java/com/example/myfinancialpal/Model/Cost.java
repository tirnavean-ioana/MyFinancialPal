package com.example.myfinancialpal.Model;

class Cost {
}
