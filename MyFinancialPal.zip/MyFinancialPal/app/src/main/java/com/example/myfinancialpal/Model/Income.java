package com.example.myfinancialpal.Model;

class Income {
}
