package com.example.myfinancialpal.Model;

public class User {
    private String username;
    private String password;

    private Cost[] costs; //cheltuieli
    private Income[] incomes;  //venituri
}
